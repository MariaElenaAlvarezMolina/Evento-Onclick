function cambieNombre(boton1) {
    boton1.innerText = "Logout";
}
function elimine(boton3) {
    boton3.remove();
}
function click_editar() {
    alert("Ninka was liked");
}